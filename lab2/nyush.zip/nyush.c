#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <signal.h>

#define MAX_ARGS 1000
#define MAX_JOBS 100

/*REFERENECES:
 -C String Library reference: https://www.tutorialspoint.com/c_standard_library/string_h.htm

 -ls ref: https://www.maths.cam.ac.uk/computing/linux/unixinfo/ls

 -C I/O: https://www.tutorialspoint.com/cprogramming/c_input_output.htm

 -int atoi() function: https://www.tutorialspoint.com/c_standard_library/c_function_atoi.htm

 -Linux Man pages dup2(), fork(), pipe(2), open(), close(), exec*(), waitpid(), signal(7) <-- [VERY IMPORTANT];
 
 -DISCORD MESSAGES
 */

typedef struct{
   pid_t pid;
   char* command[1000];
   int cmd_ct;
   int suspended; //1 = suspended
} Job;
Job jobs[MAX_JOBS];
int job_count = 0;

void sigtstp_handle(int signal){
   (void)(signal);
   //printf("\n");
}

void sigint_handle(int signal){
   (void)(signal);
   //printf("\n");
}

void add_job(Job job){

   if (job_count >= MAX_JOBS){
      fprintf(stderr, "Error: there are too many jobs\n");
      return;
   }
   jobs[job_count] = job;
   job_count++;

}

void remove_job(int job_index){
   for (int i = job_index; i < job_count - 1; i ++){
      jobs[i] = jobs[i+1];
   }
   job_count--;
}

void list_jobs(){
   for (int i = 0; i < job_count; i++){
      printf("[%d] ", i+1);
      for (int j = 0; j < jobs[i].cmd_ct; j++){
         if (jobs[i].command[j] != NULL){
            printf("%s", jobs[i].command[j]);
         }
         if (j < jobs[i].cmd_ct - 1){
            printf(" ");
         }
      }
   printf("\n");
   }
}

void pipe_command(char** commands, int num_commands){

   int num_pipes = num_commands - 1;
   int i;
   int status;
   pid_t pid;

   int fd[2*num_pipes]; 
   
   for (int i = 0; i < num_pipes; i++){

      if(pipe(fd + 2*i) < 0){
         perror("pipe error");
         exit(EXIT_FAILURE);
      }
   }

   for (i = 0; i <= num_pipes; i++){
      pid = fork();

      if (pid < 0){
         perror("Fork error");
         exit(EXIT_FAILURE);
      }else if (pid == 0){//child

         if(i == 0){
            dup2(fd[1], STDOUT_FILENO);
         }else if (i == num_pipes){//last command
            dup2(fd[(i-1)*2], STDIN_FILENO);
         }else{
            dup2(fd[(i-1)*2], STDIN_FILENO);

            dup2(fd[i*2+1], STDOUT_FILENO);
         }

         //close pipes for child
         for (int j = 0; j < 2*num_pipes; j++){
            close(fd[j]);
         }

        
         char* args[1000];
         char* arg = strtok(commands[i], " ");
         int k = 0;
         while (arg != NULL){
            args[k++] = arg;
            arg = strtok(NULL, " ");
         }
         args[k] = NULL;

         //exec_command()
         if (args[0] != NULL){
        
            int rinput = 0;
            int routput = 0;
            int appendout = 0;
            char *input_file = NULL;
            char *output_file = NULL;

            for (int i = 0; i < k; i++){

               if (strcmp(args[i], "<") == 0){
                  rinput = 1;
                  input_file = args[i + 1];
                  args[i] = NULL;
               }else if (strcmp(args[i], ">") == 0){
                  routput = 1;
                  output_file = args[i + 1];
                  args[i] = NULL;
               }else if (strcmp(args[i], ">>") == 0){
                  appendout = 1;
                  output_file = args[i + 1];
                  args[i] = NULL;
               }
            }
            //exec
            if (rinput){
            int fd = open(input_file, O_RDONLY);
            if (fd == -1){
               fprintf(stderr, "Error: invalid file\n");
               exit(EXIT_FAILURE);
            }
            dup2(fd, STDIN_FILENO);
            close(fd);
            }
            if (routput){
               int fd = open(output_file, O_WRONLY | O_CREAT | O_TRUNC, 0644);
               if (fd == -1){
                  fprintf(stderr, "Error: invalid file\n");
                  exit(EXIT_FAILURE);
               }
            dup2(fd, STDOUT_FILENO);
            close(fd);
            }
            if (appendout){
               int fd = open(output_file, O_WRONLY | O_CREAT | O_APPEND, 0644);
               if (fd == -1){
                  fprintf(stderr, "Error: invalid file\n");
                  exit(EXIT_FAILURE);
               }
            dup2(fd, STDOUT_FILENO);
            close(fd);
            }

            int error;
            error = execvp(args[0], args);
            if (error == -1){
               fprintf(stderr, "Error: invalid program\n");
               exit(EXIT_FAILURE);
            }
         }
      }else{//parent
            
       if (i < num_pipes){
         close(fd[i*2+1]);
      }
   }
}

   for (i = 0; i < 2*num_pipes; i++){
      close(fd[i]);
   }
   //wait for children
   for (i = 0; i <= num_pipes; i++){
      wait(&status);
   }
   
}


int main(){

   signal(SIGINT, sigint_handle);
   signal(SIGTSTP, sigtstp_handle);

   char cwd[1024];
   char* dir;  
   char* input = malloc(1000 * sizeof(char));
   char* input2 = malloc(1000 * sizeof(char));
   char* input3 = malloc(1000 * sizeof(char));

   while (1){


      if (getcwd(cwd, sizeof(cwd)) != NULL){
         if (strcmp(cwd, "/") == 0){
            dir = cwd;
         }else{
            dir = strrchr(cwd, '/');
            dir++;  
         }  
      }else{
         perror("Error: Current directory not found");
         exit(EXIT_FAILURE);
      }   

      printf("[nyush %s]$ ", dir);
      fflush(stdout);

      if (fgets(input, 1000, stdin) == NULL){
         if (feof(stdin)){
            printf("\n");
            exit(EXIT_SUCCESS);
         }
         continue;
      }

      input[strcspn(input, "\n")] = '\0';
      strcpy(input2, input);
      strcpy(input3, input);

      char* args[1000];
      int arg_count = 0;
      int has_pipe = 0;
      
      args[arg_count] = strtok(input, " ");
      if (args[arg_count] == NULL){
         continue;
      }

      //primitive Grammar testing
      const char *invalid_cmdnames[] = {">", "<", ">>", "|", "*", "!", "`", "'", "\""};
      int invalidcmd;
      for (int i = 0; i < 9; i++){
         if (strcmp(args[0], invalid_cmdnames[i]) == 0){
            fprintf(stderr, "Error: invalid command\n");
            invalidcmd = 1;
            break;
         }
      }
      if (invalidcmd == 1){
         invalidcmd = 0;
         continue;
      }

      while (args[arg_count] != NULL && arg_count < MAX_ARGS - 1){
         arg_count++;
         char* token = strtok(NULL, " ");
         
         if (token != NULL && strcmp(token, "|") == 0){
            has_pipe = 1;
         }
         args[arg_count] = token;
         
      }
      args[arg_count+1] = NULL;      
      
      //pipes

      char *pipe_commands[100];
      int num_commands = 0;

      if (has_pipe){
         char *token = strtok(input2, "|");
         pipe_commands[num_commands] = token;
         while (token != NULL){
            num_commands++;
            token = strtok(NULL, "|");
            if (token != NULL){
               token++;
            }
            pipe_commands[num_commands] = token;
         }
      pipe_commands[num_commands+1] = NULL;
         
      pipe_command(pipe_commands, num_commands);
      continue;
      }
      
        if (args[0] != NULL){
        
         int rinput = 0;
         int routput = 0;
         int appendout = 0;
         char *input_file = NULL;
         char *output_file = NULL;

      for (int i = 0; i < arg_count; i++){

         if (strcmp(args[i], "<") == 0){
            rinput = 1;
            input_file = args[i + 1];
            if (input_file == NULL){
               fprintf(stderr, "Error: invalid command\n");
               invalidcmd = 1;
               break;
            }
            args[i] = NULL;
         }else if (strcmp(args[i], ">") == 0){
            routput = 1;
            output_file = args[i + 1];
            if (output_file == NULL){
               fprintf(stderr, "Error: invalid command\n");
               invalidcmd = 1;
               break;
            }
            args[i] = NULL;
         }else if (strcmp(args[i], ">>") == 0){
            appendout = 1;
            output_file = args[i + 1];
            if (output_file == NULL){
               fprintf(stderr, "Error: invalid command\n");
               invalidcmd = 1;
               break;
            }
            args[i] = NULL;
         }

      }
      if (invalidcmd == 1){
         invalidcmd = 0;
         continue;
      }

      //Built-in commands section
      //cd
      if (strcmp(args[0],"cd") == 0){
                       
         if (arg_count != 2){
            fprintf(stderr, "Error: invalid command\n");
            continue;
         }else if (chdir(args[1]) != 0){
            fprintf(stderr, "Error: invalid directory\n");
         }
         continue;
         }else if (strcmp(args[0], "exit") == 0){//exit
            if (arg_count > 1){
               fprintf(stderr, "Error: invalid command\n");
               continue;
            }
            //if suspended jobs
            if (job_count > 0){
               fprintf(stderr, "Error: there are suspended jobs\n");
               continue;
            }
            exit(EXIT_SUCCESS);
         }else if (strcmp(args[0], "jobs") == 0){  //jobs
            if (arg_count > 1){
               fprintf(stderr, "Error: invalid command\n");
               continue;
            } 
            list_jobs();
         }else if (strcmp(args[0], "fg") == 0){ //fg
            if (arg_count != 2){
               fprintf(stderr, "fg Error: invalid command\n");
               continue;
            }
            
            int job_index = atoi(args[1]) - 1;

            if (job_index < 0 || job_index >= job_count){
               fprintf(stderr, "Error: invalid job\n");
               continue;
            }

            Job job = jobs[job_index];
            kill(job.pid, SIGCONT);
            
            int status;
            waitpid(job.pid, &status, WUNTRACED);
            remove_job(job_index);
            if (WIFSTOPPED(status)){
               add_job(job);
            }
         continue;
           
         }

      pid_t pid = fork();

      if (pid < 0){
         //fork fail
         perror("fork error");
         exit(EXIT_FAILURE);
      }else if (pid == 0){//child

         signal(SIGINT, SIG_DFL);
         signal(SIGTSTP, SIG_DFL);

         if (rinput){
          int fd = open(input_file, O_RDONLY);
            if (fd == -1){
               fprintf(stderr, "Error: invalid file\n");
               exit(EXIT_FAILURE);
            }
            dup2(fd, STDIN_FILENO);
            close(fd);
         }

         if (routput){
            int fd = open(output_file, O_WRONLY | O_CREAT | O_TRUNC, 0644);
            if (fd == -1){
               fprintf(stderr, "Error: invalid file\n");
               exit(EXIT_FAILURE);
            }
            dup2(fd, STDOUT_FILENO);
            close(fd);
         }
      
         if (appendout){
            int fd = open(output_file, O_WRONLY | O_CREAT | O_APPEND, 0644);
            if (fd == -1){
               fprintf(stderr, "Error: invalid file\n");
               exit(EXIT_FAILURE);
            }
            dup2(fd, STDOUT_FILENO);
            close(fd);
         }

         int error;
         if (strchr(args[0], '/') == NULL){
            char cmd[100];
            char cmd2[100];
            strcpy(cmd, "/usr/bin/");
            strcpy(cmd2, args[0]);
            strcat(cmd, cmd2);
            
            //args[0] = cmd;
            error = execv(cmd, args);
         }else{
            error = execvp(args[0], args);
         }

         if (error == -1){
            fprintf(stderr, "Error: invalid program\n");
            exit(EXIT_FAILURE);
         }
         }else{//parent
            
            signal(SIGINT, sigint_handle);
            signal(SIGTSTP, sigtstp_handle);
            int status;
            pid_t pid2;
            pid2 = waitpid(-1, &status, WUNTRACED);

            if (WIFSTOPPED(status)){
               Job job;
               char* args2[1000];
               int i = 0;
               args2[i] = strtok(input3, " ");
               while (args2[i] != NULL){
                  i++;
                  char* token = strtok(NULL, " ");
                  args2[i] = token;
         
               }
               args2[i+1] = NULL; 

               for(int j = 0; j < arg_count; j++){
                  char* cmd = malloc(1000*sizeof(char));
                  
                  if (args2[j] != NULL){
                     strcpy(cmd, args2[j]);
                  }
                  job.command[j] = cmd;
               }
               job.command[i] = NULL;
               job.cmd_ct = arg_count;
               job.pid = pid2;
               add_job(job);
            }
         }

      }
      
   }
   free(input);
   return 0;
}